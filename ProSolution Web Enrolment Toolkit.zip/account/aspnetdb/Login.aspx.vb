﻿
Partial Class Login
    Inherits System.Web.UI.Page

End Class
