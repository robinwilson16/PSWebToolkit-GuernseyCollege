﻿
Partial Class account_aspnetdb_RecoverPassword
    Inherits System.Web.UI.Page

End Class
