﻿Imports CompassCC.CCCSystem.CCCCommon
Imports CompassCC.ProSolution.PSWebEnrolmentKit


Partial Class webcontrols_checkout_supporting_you_GCFE
    Inherits CheckoutBaseControl

    Public Overrides Sub RenderControl(writer As HtmlTextWriter)
        MyBase.RenderControl(writer)

        Dim ctl As DropDownList = TryCast(fldStudentFirstLanguageID.InternalFieldControl, DropDownList)
        Dim itemsInDropDown = ctl.Items

    End Sub

    Public HasFormErrors As Boolean = False
    Public Course As OfferingRow

    Protected Overrides Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)

        If Not IsNothing(WorkingData.ShoppingCart.Items(0)) Then
            Course = OfferingDataTable.FetchByOfferingID(WorkingData.ShoppingCart.Items(0).OfferingID)
        Else
            Course = Nothing
        End If

        WorkingData.EnrolmentRequestRow.EuroResidentID = True

        Dim ctl = fldStudentFirstLanguageID.InternalFieldControl
    End Sub

    Public Overrides Sub ValidateControl()
        If Not IsNothing(fldLearningDiffOrDisID) Then
            If IsNothing(fldLearningDiffOrDisID.Value) Then
                fldLearningDiffOrDisIDValidator.ErrorMessage = "<i class=""fa-solid fa-triangle-exclamation""></i> Please select whether you have a learning difficulty and/or disability"
                fldLearningDiffOrDisIDValidator.IsValid = False
                fldLearningDiffOrDisIDValidator.CssClass = "error alert alert-danger"
                fldLearningDiffOrDisID.CssClass = "ErrorInput"
            ElseIf CInt(fldLearningDiffOrDisID.Value) = 1 And IsNothing(fldDisabilityCategory1ID.Value) Then
                fldLearningDiffOrDisIDValidator.ErrorMessage = "<i class=""fa-solid fa-triangle-exclamation""></i> As you have stated you have a learning difficulty and/or disability, please state what this so we can support you"
                fldLearningDiffOrDisIDValidator.IsValid = False
                fldLearningDiffOrDisIDValidator.CssClass = "error alert alert-danger"
                fldLearningDiffOrDisID.CssClass = "ErrorInput"
            End If
        End If

        If Not IsNothing(fldStudentFirstLanguageID) Then
            If IsNothing(fldStudentFirstLanguageID.Value) Then
                fldStudentFirstLanguageIDValidator.ErrorMessage = "<i class=""fa-solid fa-triangle-exclamation""></i> Please select your first language"
                fldStudentFirstLanguageIDValidator.IsValid = False
                fldStudentFirstLanguageIDValidator.CssClass = "error alert alert-danger"
                fldStudentFirstLanguageID.CssClass = "ErrorInput"
            End If
        End If

        MyBase.ValidateControl()
    End Sub

    Private Sub btnContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContinue.Click

        Me.Page.Validate()

        If Me.Page.IsValid Then
            'If fldEuroResidentID.Value = False Then
            '    Response.Redirect(GetResourceValue("onlineenrolmentnotavailable_e_aspx"))
            'End If
        Else
            HasFormErrors = True
        End If
    End Sub

End Class
