﻿$(function () {
    qas.addresscapture.Initialize("div#QAS_Container");
});