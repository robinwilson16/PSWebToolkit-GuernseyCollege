﻿Imports CompassCC.CCCSystem.CCCCommon
Imports CompassCC.ProSolution.PSWebEnrolmentKit


Partial Class webcontrols_contact
    Inherits webenrolmentcontrolvalidate


End Class
